
#ifdef __cplusplus
extern "C"{
#endif
void ser_print(const char *p);
void ser_print_hex(unsigned int n);
void ser_print_hex32(unsigned int n);
#ifdef __cplusplus
} // extern "C"
#endif

